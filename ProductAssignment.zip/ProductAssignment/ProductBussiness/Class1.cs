﻿using System;

namespace ProductBussiness
{
    public class Class1
    {
    }
}
